<main class="container d-flex flex-column justify-content-center align-items-center flex-fill mt-5">
    <div class="" style="max-width: 700px;">
        <h1>Page Not Found</h1>
        <p>Sorry, but the page you were trying to view does not exist.</p>
    </div>
</main>