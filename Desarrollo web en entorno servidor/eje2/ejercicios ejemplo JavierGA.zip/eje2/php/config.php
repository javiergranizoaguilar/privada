<?php
define("nameimgs",['images','images1','images2','images3','images4','images5','images6','images7','images8','images9']);
?>
